---
title: The Hello World of Blogs
tags: [Technology, Blogging]
style: fill
color: secondary
description: This is a blog post to get you started.
---

Source: [portfolYOU](https://github.com/YoussefRaafatNasry/portfolYOU)

This is me writing an intro to this blog post.  So introlicioius.

## 1. Here is one thing I want to say

This is maybe an important thing, and, at the very least it is first.

## 2. Another thing

I am now talking about a second thing, probably also good.

## 3. A third thing

We are now getting into the weeds of things that I am saying.  It is probably unlikely someone has made it thus far.

## 4. Thing #4.

At this point, you are probably no longer into me listing off things.  Let's put in an image to placate the reader:

![corg](https://media.istockphoto.com/photos/welsh-corgi-picture-id962032196?k=20&m=962032196&s=170667a&w=0&h=NhIyQdJgVw0cw_EeLtP3LcLExLuiAWPwzL6_WsRKUfQ=)

## 5. The last thing

This is my final thing, probably would be great if this was a TL;DR or summary.  But I don't have that for you.  I have given you so little already, why start saying anything useful now?

Besides, all anybody wants is the DERP:

![MAXIMUM DERP](http://3.bp.blogspot.com/-AXnXOPZgqMk/Un-xCBAa4gI/AAAAAAAAsWA/z_lZsvDoCRk/s1600/derpstages.jpg)
